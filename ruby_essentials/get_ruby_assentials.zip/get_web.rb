require "open-uri"
class GetWeb
  HOME = "http://www.techotopia.com/index.php"

  def self.getAll
    index = "Ruby_Essentials"
    GetWeb.get(index)
    open("#{index}.html") do |f|
      pattern = /a href="\/index\.php\/(.*Ruby.*)" title=/
      f.read.scan(pattern).uniq.each do |item|
        self.get(item[0])
      end
    end
  end

  private
  def self.get(name)
    open("#{HOME}/#{name}") {|f| open("#{name}.html", "w").write(f.read)}
  end

end

GetWeb.getAll
